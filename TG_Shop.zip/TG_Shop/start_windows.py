#
# Поддержать создателя программы - https://donate.qiwi.com/payin/SashkinYT
#
import os
while True:
    os.system("cls")
    os.system("python python-bot.py")