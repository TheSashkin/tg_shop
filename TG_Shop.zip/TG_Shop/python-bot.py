#
# Поддержать создателя программы - https://donate.qiwi.com/payin/SashkinYT
#
import telebot
from SimpleQIWI import *
from config import *
api = QApi(token=qtoken, phone=phone)
print(api.balance)
bot = telebot.TeleBot(token=tgtoken)
@bot.message_handler(commands=["start"])
def start(message):
    bot.send_message(message.chat.id, f"Привет, {message.from_user.first_name}!\n🛒Здесь я проверяю библиотеку SimpleQiwi🛒\n💵Купить - /buy💵")
@bot.message_handler(commands=["buy"])
def buy(message):
    price = 1
    try:
        m_split = message.text.split(" ")
        if m_split[1] == "confirm":
            comment = api.bill(price)
            bot.send_message(message.chat.id, f"✔Цена✔ - {price}р.\nСчёт: {url}\nКомментарий к переводу:\n{comment}\nВремя на оплату: 10мин.")
            api.start()
            timer = 0
            while True:
                if api.check(comment):
                    bot.send_message(message.chat.id, f"✔Вы успешно оплатили товар✔\nКлюч активации: {key}")
                    print(f"{timer}){comment} успешно оплачен!")
                    bot.send_message("asdasd")
                elif timer == 600:
                    bot.send_message(message.chat.id, "❌Вы не успели оплатить❌")
                    print(f"{timer}){comment} Не успели оплатить!")
                    bot.send_message("asdasd")
                else:
                    print(f"{timer}){comment} ещё не оплачен!")
                time.sleep(1)
                timer += 1
    except IndexError:
        bot.send_message(message.chat.id, f"✔Цена✔ - {price}р.\nПодтвердить покупку - /buy confirm")
    except OverridingEx:
        bot.send_message(message.chat.id, f"❌Кто-то уже оплачивает товар❌")
bot.polling()