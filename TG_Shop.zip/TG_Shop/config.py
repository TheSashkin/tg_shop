#
# Поддержать создателя программы - https://donate.qiwi.com/payin/SashkinYT
#
phone = "Ваш номер телефона"
qtoken = "Токен Qiwi API"
tgtoken = "Токен Telegram бота"
key = "Ключ активации продукта"
url = "Ссылка для доната(https://qiwi.com/n/SASHKINYT)"